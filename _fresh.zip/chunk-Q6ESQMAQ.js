import{g as r}from"./chunk-V7IMYVGJ.js";var s=r([]);var d=r(void 0);function n(t){return t.children}n.displayName="Partial";
