import{e as o}from"./chunk-A24ONYSU.js";import"./chunk-4C7GSA6N.js";import"./chunk-JG7V63GM.js";export{o as signal};
