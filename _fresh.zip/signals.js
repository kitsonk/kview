import{e as o}from"./chunk-BLU3JEWT.js";import"./chunk-V7IMYVGJ.js";export{o as signal};
