import{e as o}from"./chunk-NZ7I2266.js";import"./chunk-TJ4GUT72.js";import"./chunk-JG7V63GM.js";export{o as signal};
